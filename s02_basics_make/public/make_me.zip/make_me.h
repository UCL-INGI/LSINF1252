#include <stdio.h>

/*
 * Prints the string "Make me"  on stdout
 */
void print_make_me();
