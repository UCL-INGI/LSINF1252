#include "make_me.h"            /* header file */

int main() {
        print_make_me();
        return 0;
}

void print_make_me() {
        printf("Make me\n");
}
