#ifndef __MAKE_ME_H
#define __MAKE_ME_H

#include <stdio.h>

/*
 * Prints the string "Make me" on stdout
 */
void print_make_me();

#endif
